//
//  ListVC.m
//  ProofOfConcept
//
//  Created by SYS-27 on 11/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//
#define Screen_height  [UIScreen mainScreen].bounds.size.height
#define Screen_width  [UIScreen mainScreen].bounds.size.width

#import "ListVC.h"
#import <UIImageView+WebCache.h>

@interface ListVC (){
    NSMutableArray *responseArray;
    UIRefreshControl *refreshControler;
}
@end

@implementation ListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    responseArray=[[NSMutableArray alloc] init];
    refreshControler = [[UIRefreshControl alloc] init];
     _activityIndicator.hidden=NO;
    [_activityIndicator startAnimating];
    if (@available(iOS 10.0, *)) {
        _listTableview.refreshControl = refreshControler;
    }
   [refreshControler addTarget:self action:@selector(pullToRefresh:) forControlEvents:UIControlEventValueChanged];
    _listTableview.rowHeight = UITableViewAutomaticDimension;
    _listTableview.estimatedRowHeight = 68;
    [self getListService];
}
#pragma UIRefreshControl Action
- (IBAction)pullToRefresh:(id)sender {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            //UI refresh
            [self getListService];
            [refreshControler beginRefreshing];
        });
    });
}
#pragma Service Call Method
-(void)getListService{
    NSCharacterSet *expectedCharSet = [NSCharacterSet URLQueryAllowedCharacterSet];
    NSString *urlString = [@"https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json" stringByAddingPercentEncodingWithAllowedCharacters:expectedCharSet];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:url completionHandler:^(NSData* data, NSURLResponse* response, NSError *error){
        if(data != nil){
            NSString *latinString = [[NSString alloc] initWithData:data encoding:NSISOLatin1StringEncoding];
            NSData *jsonData = [latinString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves error:&error];
            NSLog(@"response = %@",json);
            dispatch_async(dispatch_get_main_queue(), ^(void){
                _activityIndicator.hidden=YES;
               [_activityIndicator stopAnimating];
               [refreshControler endRefreshing];
               self.navigationItem.title = [json valueForKey:@"title"];
               responseArray=[json valueForKey:@"rows"];
                [_listTableview reloadData];
            });
        }else{
            UIAlertController *alertController = [UIAlertController  alertControllerWithTitle:@"POC"  message:@"No Internet Connection Available!"  preferredStyle:UIAlertControllerStyleAlert];
            [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [self dismissViewControllerAnimated:YES completion:nil];
            }]];
            [self presentViewController:alertController animated:YES completion:nil];
        }
    }];
    [dataTask resume];
}
#pragma UITableviewDatasorce Protocol
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;  //count of section
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [responseArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *titleStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
    NSString *descriptionStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
    NSString *imgStr=[[responseArray objectAtIndex:indexPath.row]valueForKey:@"imageHref"];
    
    ListCell *cell = (ListCell *)[tableView dequeueReusableCellWithIdentifier:@"ListCellIdentifier" forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[ListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ListCellIdentifier"];
    }
    
    if (![titleStr isKindOfClass:[NSNull class]]) {
        if ([titleStr length] > 0) {
            cell.titleLabel.text = [[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
        }
    } else {
        cell.titleLabel.text = @"No title available right now";
    }
    
    if (![descriptionStr isKindOfClass:[NSNull class]]) {
        if ([descriptionStr length] > 0) {
          cell.descriptionLabel.text=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
        }
    } else {
        cell.descriptionLabel.text = @"No description available right now";
    }
    
    if (![imgStr isKindOfClass:[NSNull class]]) {
        
        if ([imgStr length] > 0) {
        dispatch_async(dispatch_get_main_queue(), ^(void){
        //Run UI Updates
        [cell.imageHref sd_setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed:@"noimage"]];
        });
        }
        
    } else {
        cell.imageHref.image = [UIImage imageNamed:@"noimage"];
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *imgStr=[[responseArray objectAtIndex:indexPath.row]valueForKey:@"imageHref"];
    NSString *titleStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
    NSString *descriptionStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
    
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view setBackgroundColor:[UIColor whiteColor]];
    
    UIView  *manaView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, Screen_width , Screen_height)] ;
    manaView.backgroundColor = [UIColor whiteColor];
    [manaView setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [manaView setAutoresizingMask:UIViewAutoresizingFlexibleWidth];

    
    UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, Screen_width , Screen_height)];
    scroll.contentSize = CGSizeMake(Screen_width, 800);
    scroll.showsHorizontalScrollIndicator = YES;
    [scroll setShowsHorizontalScrollIndicator:NO];
    [scroll setShowsVerticalScrollIndicator:NO];
    [scroll setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [scroll setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [manaView addSubview:scroll];
 
    
    UIImageView *imageImg = [[UIImageView alloc]init];
    imageImg.frame = CGRectMake(0,30,Screen_width,250);
    imageImg.contentMode=UIViewContentModeScaleAspectFit;
    [imageImg setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [imageImg setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [vc.view addSubview:manaView];
    [scroll addSubview:imageImg];
    
    UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(8, 310, 359, 20)];
    nameLabel.font = [UIFont fontWithName:@"" size:14]; //custom font
    nameLabel.numberOfLines = 0;
    nameLabel.lineBreakMode = NSLineBreakByWordWrapping;
    nameLabel.baselineAdjustment = YES;
    nameLabel.adjustsFontSizeToFitWidth = YES;
    nameLabel.clipsToBounds = YES;
    nameLabel.textColor = [UIColor blackColor];
    nameLabel.textAlignment = NSTextAlignmentLeft;
    [nameLabel setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [nameLabel setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [scroll addSubview:nameLabel];
    
    UILabel *descriptionLabel = [[UILabel alloc]initWithFrame:CGRectMake(8, 330, 359, 110)];
    [descriptionLabel setFont:[UIFont systemFontOfSize:12]];
    descriptionLabel.numberOfLines = 0;
    descriptionLabel.lineBreakMode = NSLineBreakByWordWrapping;
    descriptionLabel.baselineAdjustment = YES;
    descriptionLabel.adjustsFontSizeToFitWidth = YES;
    descriptionLabel.clipsToBounds = YES;
    descriptionLabel.textColor = [UIColor blackColor];
    descriptionLabel.textAlignment = NSTextAlignmentLeft;
    [descriptionLabel setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [descriptionLabel setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [scroll addSubview:descriptionLabel];
    
    
     self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    if (![titleStr isKindOfClass:[NSNull class]]) {
        if ([titleStr length] > 0) {
            nameLabel.text = titleStr;
            NSLog(@"nameLabel.text = %@",nameLabel.text);
        }
    }else{
        nameLabel.text = @"No title available right now";
    }
    if (![descriptionStr isKindOfClass:[NSNull class]]) {
        if ([descriptionStr length] > 0) {
            descriptionLabel.text=descriptionStr;
            NSLog(@"descriptionLabel.text = %@",descriptionLabel.text);
        }
    }else{
        descriptionLabel.text = @"No description available right now";
    }
    
    if (![imgStr isKindOfClass:[NSNull class]]) {
        if ([imgStr length] > 0) {
            [imageImg sd_setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed: @"noimage"]];
        }
    }else {
        [imageImg sd_setImageWithURL:[NSURL URLWithString:@""] placeholderImage:[UIImage imageNamed:@"noimage"]];
    }
    [self.navigationController pushViewController:vc animated:TRUE];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
