//
//  ListCell.m
//  ProofOfConcept
//
//  Created by SYS-27 on 11/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import "ListCell.h"

@implementation ListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    _imageHref.layer.cornerRadius=_imageHref.frame.size.width/2.0;
    _imageHref.clipsToBounds=TRUE;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
