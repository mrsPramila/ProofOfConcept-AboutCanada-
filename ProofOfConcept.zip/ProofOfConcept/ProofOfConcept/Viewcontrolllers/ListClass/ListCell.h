//
//  ListCell.h
//  ProofOfConcept
//
//  Created by SYS-27 on 11/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageHref;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *descriptionLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imagewidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageRightMargin;
@property (strong, nonatomic) IBOutlet UILabel *noImageAvailableLabel;

@end
